# Input path handling for start.cmd: sidecar write (-File) or ConvertTo-EcWindowsPath when dot-sourced.

function ConvertTo-EcWindowsPath {
    param([string]$Raw)
    $bs = [char]92
    $p = $Raw.Trim()
    if ($p.Length -eq 0) { return $null }

    if ($p.Length -ge 2 -and $p[0] -eq $bs -and $p[1] -eq $bs) {
        return $p.TrimEnd($bs)
    }

    if ($p -match '^/mnt/([a-zA-Z])/(.*)$') {
        $d = $matches[1].ToUpperInvariant()
        $rest = $matches[2] -replace '/', $bs
        return ($d + ':' + $bs + $rest).TrimEnd($bs)
    }

    if ($p -match '^/cygdrive/([a-zA-Z])/(.*)$') {
        $d = $matches[1].ToUpperInvariant()
        $rest = $matches[2] -replace '/', $bs
        return ($d + ':' + $bs + $rest).TrimEnd($bs)
    }

    if ($p.StartsWith('/')) {
        $norm = $p.TrimStart('/')
        $slash = $norm.IndexOf('/')
        if ($slash -lt 0) {
            $first = $norm
            $rest = ''
        }
        else {
            $first = $norm.Substring(0, $slash)
            $rest = $norm.Substring($slash + 1)
        }
        if ($first.Length -eq 1 -and $first -match '^[a-zA-Z]$') {
            $d = $first.ToUpperInvariant()
            $rest2 = $rest -replace '/', $bs
            return ($d + ':' + $bs + $rest2).TrimEnd($bs)
        }
    }

    if ($p -match '^([a-zA-Z]):[\\/](.*)$') {
        $d = $matches[1].ToUpperInvariant()
        $rest = $matches[2] -replace '/', $bs
        return ($d + ':' + $bs + $rest).TrimEnd($bs)
    }
    if ($p -match '^([a-zA-Z]):$') {
        return $matches[1].ToUpperInvariant() + ':' + $bs
    }

    if ($p.IndexOf('/') -ge 0) {
        return ($p -replace '/', $bs).TrimEnd($bs)
    }

    return $p.TrimEnd($bs)
}

if ($MyInvocation.InvocationName -ne '.') {
    $ErrorActionPreference = 'Stop'
    if ($args.Count -lt 3) { exit 1 }
    $raw = ($args[2..($args.Count - 1)] -join ' ').Trim()
    if ([string]::IsNullOrWhiteSpace($raw)) { exit 1 }
    $out = $env:EC_PATH_FILE
    if ([string]::IsNullOrWhiteSpace($out)) { exit 1 }
    $utf8 = New-Object System.Text.UTF8Encoding $false
    [System.IO.File]::WriteAllText($out, $raw, $utf8)
    exit 0
}
