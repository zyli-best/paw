---
name: vuln-scan
description: |
  BIOS/Firmware 代码安全扫描技能。当用户要求扫描 BIOS 代码、firmware 代码漏洞、
  安全检查、脆弱性分析、或任何涉及对代码目录进行安全审计时触发。
  只要用户提到"扫描"、"安全扫描"、"漏洞扫描"、"安全检查"等关键词，
  且涉及代码路径、项目目录、BIOS/firmware 代码，就应该使用此技能。
  不要仅在用户明确说"运行扫描"时才触发 — 任何代码安全审计相关的请求都应考虑使用。
compatibility:
  required_tools:
    - execute_shell_command
---

# vuln-scan — BIOS/Firmware 代码安全扫描

## 核心任务

只做一件事：**对指定路径的 BIOS 代码执行安全扫描并返回结果**。

## 输入参数

| 参数 | 类型 | 必填 | 说明 |
|------|:----:|:----:|------|
| `projectFolder` | string | ✅ | 待扫描代码的**绝对路径** |

## result.json 格式

扫描完成后，`scripts/` 目录下生成 `result.json`，结构如下：

```json
{
  "code": 0,
  "msg": "scan result message",
  "log_file": "D:\\path\\to\\report.txt"
}
```

- **`code == 0`** → 扫描成功
- **`code != 0`** → 扫描失败，通过 `msg` 获取失败原因

## 工作流程

### Step 1: 验证目录

检查 `projectFolder` 是否存在且为一个目录：

```cmd
dir "%projectFolder%"
```

如果目录不存在，**直接返回错误**，不重试。

### Step 2: 执行扫描

找到 skill 的 `scripts/` 目录路径，执行：

```cmd
cd /d <skill-scripts-path>
start.cmd "%projectFolder%"
```

**超时参数：**
- `execute_shell_command` 的 `timeout` 设为 **3600 秒（1 小时）**
- 扫描可能耗时较长，设置足够大的超时

### Step 3: 耐心等待

- 扫描可能耗时 10 分钟 ~ 1 小时，**不要中断、不要催促**
- 即使 stdout 长时间没有输出，也保持等待
- 不到超时绝不提前终止

### Step 4: 检查结果

读取 `scripts/result.json`：

| 情况 | 判定 | 处理 |
|------|:----:|------|
| `code == 0` | ✅ 成功 | 返回扫描结果（`msg` 和 `log_file` 内容） |
| `code != 0` | ❌ 失败 | 读取 `msg`，直接返回失败原因 |
| 文件不存在 | ❌ 失败 | 报错："未找到扫描结果文件" |
| 格式异常 | ❌ 失败 | 报错："结果文件格式异常" |

### Step 5: 输出结果

**成功时：** 简要返回扫描结果信息。
**失败时：** 直接输出 `result.json` 中的 `msg` 作为失败原因。

## ⚠️ 硬性规则

1. **禁止重试** — 扫描失败直接报告原因，绝不自动重试
2. **耐心等待** — 设置 3600 秒超时，不中途打断
3. **只扫不修** — 不修改代码、不修复漏洞，只报告扫描结果
4. **保持简洁** — 输出结果简短直接，不啰嗦
5. **不越界** — 只操作传入的 `projectFolder` 目录和 skill 自身的 `scripts/` 目录

## 错误处理

| 场景 | 处理方式 |
|------|----------|
| projectFolder 不存在 | 直接报错："项目目录不存在：[路径]" |
| start.cmd 找不到 RunCheck.ps1 | 报错："缺少依赖文件 RunCheck.ps1" |
| 扫描执行超时 | 报错："扫描超时（已等待1小时）" |
| result.json 不存在 | 报错："未找到扫描结果文件" |
| result.json 中 `code != 0` | 报错："扫描失败：[msg 内容]" |
| result.json 解析失败 | 报错："结果文件格式异常" |

**所有错误场景均不重试。**
